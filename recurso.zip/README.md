# CREA-edu
Estilo CREA-edu para eXeLearning

Características: 
 iDevices minimizados al inicio. Usando los iconos Collapase_idevice o con ** al inicio del título del iDevice
 En la edición de iDevices, los iconos de aceptar cambios, rechazar, borrar,.... aparecen más grandes

iDevice DUA: Cambio de posición de de los iconos de lectura faciltiada, ....

Características de accesibilidad: modo alto contraste, cuatro tipografías, tamaño de letra, sintetizador de voz, ....

 En modo visualización se mantienen las preferencias del usuario dentro del mismo navegador: modo alto contraste, tipografía, tamaño de letra, visualización de menú y también mantiene la última página/nodo que el usuario visitó.

 Se marca la cabecera del iDevice sobre el que pasa el ratón.

 Se añaden algunas animaciones: botones de 
 cuando idevice texto solo contiene imagen, se usa como separador de bloques, por lo que no tiene ningún adorno el idevice

